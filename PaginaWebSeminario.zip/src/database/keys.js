module.exports = {
    mongodb: {
        URI: 'mongodb+srv://alekzdevz93:xu5Ef2UyenOd2i9c@devstandalone-p8zla.gcp.mongodb.net/radio_xhipn?retryWrites=true&w=majority'
    }
}



/*const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://<callback1_user>:<hesoyamz58>@devstandalone-p8zla.gcp.mongodb.net/test?retryWrites=true&w=majority";
const client = new MongoClient(uri, { useNewUrlParser: true });
client.connect(err => {
  const collection = client.db("test").collection("devices");
  // perform actions on the collection object
  client.close();
});

--------------------
mongodb+srv://<username>:<password>@devstandalone-p8zla.gcp.mongodb.net/test?retryWrites=true&w=majority

'mongodb://localhost:27017/radio_xhipn'

*/ 
